Product: The George, December 2014

Designer: Dylan Stallard

Support:  http://forums.obrary.com/category/designs/the-george

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design